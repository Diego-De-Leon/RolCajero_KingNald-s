package kingnalds.cajero;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class CashierApp extends JFrame {
    private static final Color BG = new Color(3, 4, 4);
    private static final Color PANEL = new Color(7, 7, 7);
    private static final Color PANEL_2 = new Color(12, 12, 11);
    private static final Color LINE = new Color(122, 88, 18);
    private static final Color GOLD = new Color(221, 171, 49);
    private static final Color GOLD_2 = new Color(247, 207, 104);
    private static final Color TEXT = new Color(248, 240, 216);
    private static final Color MUTED = new Color(196, 181, 148);
    private static final Color RED = new Color(92, 10, 17);
    private static final Color GREEN = new Color(201, 178, 106);
    private static final DecimalFormat MONEY = new DecimalFormat("Q0.00");

    private final CardLayout mainCards = new CardLayout();
    private final JPanel mainArea = new JPanel(mainCards);
    private final JPanel productsGrid = new JPanel(new GridLayout(0, 5, 10, 10));
    private final JPanel productsHolder = new JPanel(new BorderLayout());
    private final JScrollPane productsScroll = new JScrollPane(productsHolder);
    private final JPanel categoryBar = new JPanel(new GridLayout(1, 6, 10, 0));
    private final Map<String, JButton> categoryButtons = new LinkedHashMap<>();
    private final JTextField search = darkField("Buscar productos...");
    private final JLabel dateLabel = label("", 11, MUTED);
    private final JLabel timeLabel = label("", 14, TEXT);

    private final JPanel cartList = new JPanel();
    private final JLabel subtotalValue = label("Q0.00", 13, TEXT);
    private final JLabel taxValue = label("Q0.00", 13, TEXT);
    private final JLabel totalValue = label("Q0.00", 25, BG);
    private final JTextField receivedField = darkField("0.00");
    private final JLabel changeValue = label("Q0.00", 13, GREEN);
    private final ButtonGroup paymentGroup = new ButtonGroup();
    private final JToggleButton cashBtn = paymentButton("▣  Efectivo");
    private final JToggleButton cardBtn = paymentButton("▤  Tarjeta");
    private final JToggleButton transferBtn = paymentButton("⇄  Transferencia");
    private final ButtonGroup orderTypeGroup = new ButtonGroup();
    private final JToggleButton localBtn = toggleButton("♨  Local");
    private final JToggleButton takeawayBtn = toggleButton("▢  Para llevar");
    private final JComboBox<String> customerCombo = darkCombo("Cliente Genérico", "Carlos Méndez", "Ana Rodríguez", "Luis Pérez", "Sofía Gómez");
    private final JLabel orderNo = label("# Orden: 001248", 11, TEXT);

    private final java.util.List<Product> products = new ArrayList<>();
    private final LinkedHashMap<Product, Integer> cart = new LinkedHashMap<>();
    private final java.util.List<OrderRecord> orders = new ArrayList<>();
    private String activeCategory = "Hamburguesas";
    private int nextOrder = 1249;

    private DefaultTableModel ordersModel;
    private JTable ordersTable;
    private JComboBox<String> statusFilter;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) {}
            new CashierApp().setVisible(true);
        });
    }

    public CashierApp() {
        super("KingNald's | Caja");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1440, 810);
        setMinimumSize(new Dimension(1180, 720));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        seedProducts();
        seedOrders();
        add(buildHeader(), BorderLayout.NORTH);
        add(buildMain(), BorderLayout.CENTER);
        cashBtn.setSelected(true);
        localBtn.setSelected(true);
        refreshProducts();
        refreshCart();
        startClock();
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(18, 0));
        header.setBackground(BG);
        header.setBorder(new MatteBorder(0, 0, 1, 0, LINE));
        header.setPreferredSize(new Dimension(0, 70));

        JPanel brand = new JPanel(new BorderLayout(10, 0));
        brand.setOpaque(false);
        brand.setBorder(new EmptyBorder(8, 18, 8, 0));
        JLabel crown = label("♛", 37, GOLD);
        brand.add(crown, BorderLayout.WEST);
        JPanel brandText = new JPanel();
        brandText.setOpaque(false);
        brandText.setLayout(new BoxLayout(brandText, BoxLayout.Y_AXIS));
        JLabel king = label("KINGNALD’S", 27, TEXT); king.setFont(new Font("Serif", Font.BOLD, 27));
        JLabel tag = label("ROYAL BURGER HOUSE", 10, GOLD);
        brandText.add(king); brandText.add(tag);
        brand.add(brandText, BorderLayout.CENTER);
        brand.setPreferredSize(new Dimension(315, 70));
        header.add(brand, BorderLayout.WEST);

        JPanel searchWrap = new JPanel(new BorderLayout());
        searchWrap.setOpaque(false);
        searchWrap.setBorder(new EmptyBorder(13, 0, 13, 0));
        search.setFont(new Font("SansSerif", Font.PLAIN, 13));
        searchWrap.add(search, BorderLayout.CENTER);
        header.add(searchWrap, BorderLayout.CENTER);

        JPanel meta = new JPanel(new GridLayout(1, 2, 0, 0));
        meta.setOpaque(false);
        meta.setPreferredSize(new Dimension(360, 70));
        JPanel clock = new JPanel(); clock.setOpaque(false); clock.setLayout(new BoxLayout(clock, BoxLayout.Y_AXIS));
        clock.setBorder(new CompoundBorder(new MatteBorder(0,1,0,1,LINE), new EmptyBorder(10,16,7,16)));
        dateLabel.setAlignmentX(Component.CENTER_ALIGNMENT); timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        timeLabel.setFont(new Font("Serif", Font.BOLD, 14));
        clock.add(dateLabel); clock.add(Box.createVerticalStrut(4)); clock.add(timeLabel);
        JPanel user = new JPanel(new BorderLayout(10,0)); user.setOpaque(false); user.setBorder(new EmptyBorder(10,18,10,18));
        JLabel person = label("♟", 28, GOLD); user.add(person, BorderLayout.WEST);
        JPanel ut = new JPanel(); ut.setOpaque(false); ut.setLayout(new BoxLayout(ut,BoxLayout.Y_AXIS));
        ut.add(label("Cajero",10,MUTED)); JLabel name=label("María López",13,TEXT); name.setFont(new Font("Serif",Font.BOLD,13)); ut.add(name); user.add(ut,BorderLayout.CENTER);
        user.add(label("⌄",16,TEXT),BorderLayout.EAST);
        meta.add(clock); meta.add(user);
        header.add(meta, BorderLayout.EAST);

        search.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e){refreshProducts();}
            public void removeUpdate(DocumentEvent e){refreshProducts();}
            public void changedUpdate(DocumentEvent e){refreshProducts();}
        });
        return header;
    }

    private JComponent buildMain() {
        JPanel root = new JPanel(new BorderLayout(12,0));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(10, 14, 10, 14));

        JPanel left = new JPanel(new BorderLayout(0,10)); left.setBackground(BG);
        left.add(buildCategoryBar(), BorderLayout.NORTH);

        JPanel menuPage = buildMenuPage();
        JPanel ordersPage = buildOrdersPage();
        mainArea.setBackground(BG);
        mainArea.add(menuPage,"MENU");
        mainArea.add(ordersPage,"ORDERS");
        left.add(mainArea, BorderLayout.CENTER);
        left.setPreferredSize(new Dimension(930,0));
        root.add(left,BorderLayout.CENTER);
        root.add(buildRightPanel(),BorderLayout.EAST);
        return root;
    }

    private JComponent buildCategoryBar() {
        categoryBar.setOpaque(false);
        categoryBar.setPreferredSize(new Dimension(0, 58));
        String[] cats = {"Hamburguesas","Combos","Bebidas","Papas","Postres","Pedidos"};
        String[] icons = {"●","♨","▣","▥","♜","▤"};
        for(int i=0;i<cats.length;i++){
            JButton b = roundedButton(icons[i]+"  "+cats[i], PANEL_2, TEXT, 14);
            final String cat = cats[i];
            b.addActionListener(e->{
                if(cat.equals("Pedidos")) { mainCards.show(mainArea,"ORDERS"); }
                else { activeCategory=cat; mainCards.show(mainArea,"MENU"); refreshProducts(); }
                updateCategoryStyles(cat);
            });
            categoryButtons.put(cat,b); categoryBar.add(b);
        }
        updateCategoryStyles("Hamburguesas");
        return categoryBar;
    }

    private JPanel buildMenuPage() {
        JPanel page = new JPanel(new BorderLayout(0,10)); page.setBackground(BG);
        productsGrid.setBackground(BG);
        productsHolder.setBackground(BG);
        productsHolder.add(productsGrid, BorderLayout.NORTH);
        productsScroll.setBorder(null);
        productsScroll.getViewport().setBackground(BG);
        productsScroll.getVerticalScrollBar().setUnitIncrement(16);
        page.add(productsScroll,BorderLayout.CENTER);
        page.add(buildBottomControls(),BorderLayout.SOUTH);
        return page;
    }

    private JComponent buildBottomControls(){
        JPanel south = new JPanel(new BorderLayout(10,10)); south.setBackground(BG);
        JPanel top = new JPanel(new GridLayout(1,2,10,0)); top.setOpaque(false);
        JPanel client = cardPanel(new BorderLayout(8,8),10);
        JLabel ct=label("♟   Información del Cliente",12,GOLD_2); ct.setFont(new Font("Serif",Font.BOLD,12)); client.add(ct,BorderLayout.NORTH);
        JPanel cr = new JPanel(new BorderLayout(8,0)); cr.setOpaque(false); cr.add(customerCombo,BorderLayout.CENTER);
        JButton newClient=roundedButton("＋ Nuevo cliente",PANEL_2,TEXT,12); newClient.addActionListener(e->showNewClientDialog()); cr.add(newClient,BorderLayout.EAST); client.add(cr,BorderLayout.CENTER);
        top.add(client);
        JPanel type=cardPanel(new BorderLayout(8,8),10); JLabel tt=label("▣   Tipo de pedido",12,GOLD_2); tt.setFont(new Font("Serif",Font.BOLD,12)); type.add(tt,BorderLayout.NORTH);
        JPanel types=new JPanel(new GridLayout(1,2,8,0)); types.setOpaque(false); orderTypeGroup.add(localBtn); orderTypeGroup.add(takeawayBtn); types.add(localBtn); types.add(takeawayBtn); type.add(types,BorderLayout.CENTER); top.add(type);
        south.add(top,BorderLayout.CENTER);
        JPanel actions=new JPanel(new GridLayout(1,3,10,0)); actions.setOpaque(false); actions.setPreferredSize(new Dimension(0,52));
        JButton cancel=roundedButton("✕   Cancelar",RED,TEXT,13); cancel.addActionListener(e->{cart.clear();refreshCart();});
        JButton ticket=roundedButton("▤   Imprimir ticket",PANEL_2,TEXT,13); ticket.addActionListener(e->showTicket());
        JButton fresh=roundedButton("▤   Nuevo pedido",PANEL_2,TEXT,13); fresh.addActionListener(e->newOrder());
        actions.add(cancel); actions.add(ticket); actions.add(fresh); south.add(actions,BorderLayout.SOUTH);
        return south;
    }

    private JPanel buildOrdersPage(){
        JPanel page=new JPanel(new BorderLayout(0,10));page.setBackground(BG);
        JPanel tableCard=cardPanel(new BorderLayout(0,10),12);
        JPanel title=new JPanel(new BorderLayout());title.setOpaque(false); JLabel l=label("☷   Lista de Pedidos",20,GOLD_2);l.setFont(new Font("Serif",Font.BOLD,20));title.add(l,BorderLayout.WEST);
        statusFilter=darkCombo("Todos los estados","Pendiente","En preparación","Completado","Entregado"); statusFilter.setPreferredSize(new Dimension(210,38));statusFilter.addActionListener(e->refreshOrdersTable());title.add(statusFilter,BorderLayout.EAST);tableCard.add(title,BorderLayout.NORTH);
        ordersModel=new DefaultTableModel(new String[]{"ID Pedido","Cliente","Estado","Total","Hora","Tipo de pedido","Acción"},0){public boolean isCellEditable(int r,int c){return false;}};
        ordersTable=new JTable(ordersModel);ordersTable.setRowHeight(42);ordersTable.setBackground(PANEL);ordersTable.setForeground(TEXT);ordersTable.setGridColor(LINE);ordersTable.setSelectionBackground(new Color(38,50,69));ordersTable.setSelectionForeground(TEXT);ordersTable.getTableHeader().setBackground(PANEL_2);ordersTable.getTableHeader().setForeground(TEXT);ordersTable.setFont(new Font("SansSerif",Font.PLAIN,12));ordersTable.getTableHeader().setFont(new Font("SansSerif",Font.BOLD,12));
        JScrollPane sp=new JScrollPane(ordersTable);sp.setBorder(new LineBorder(LINE));sp.getViewport().setBackground(PANEL);tableCard.add(sp,BorderLayout.CENTER);
        ordersTable.addMouseListener(new MouseAdapter(){public void mouseClicked(MouseEvent e){int r=ordersTable.rowAtPoint(e.getPoint());int c=ordersTable.columnAtPoint(e.getPoint());if(r>=0&&c==6)showOrderDetails(String.valueOf(ordersTable.getValueAt(r,0)));}});
        page.add(tableCard,BorderLayout.CENTER);
        JPanel actions=new JPanel(new GridLayout(1,3,10,0));actions.setOpaque(false);actions.setPreferredSize(new Dimension(0,52));
        JButton cancel=roundedButton("✕   Cancelar",RED,TEXT,13);cancel.addActionListener(e->mainCards.show(mainArea,"MENU"));
        JButton print=roundedButton("▤   Imprimir ticket",PANEL_2,TEXT,13);print.addActionListener(e->showTicket());
        JButton fresh=roundedButton("▤   Nuevo pedido",PANEL_2,TEXT,13);fresh.addActionListener(e->{newOrder();mainCards.show(mainArea,"MENU");updateCategoryStyles(activeCategory);});actions.add(cancel);actions.add(print);actions.add(fresh);page.add(actions,BorderLayout.SOUTH);
        refreshOrdersTable();return page;
    }

    private JComponent buildRightPanel(){
        JPanel right=new JPanel(new BorderLayout(0,10));right.setBackground(BG);right.setPreferredSize(new Dimension(460,0));
        JPanel summary=royalPanel(new BorderLayout(0,8),12);
        JPanel h=new JPanel(new BorderLayout());h.setOpaque(false); JLabel title=label("🛒  TU BANQUETE",17,GOLD_2);title.setFont(new Font("Serif",Font.BOLD,17));h.add(title,BorderLayout.WEST);h.add(orderNo,BorderLayout.EAST);summary.add(h,BorderLayout.NORTH);
        cartList.setBackground(new Color(58, 7, 10));cartList.setLayout(new BoxLayout(cartList,BoxLayout.Y_AXIS));JScrollPane cartScroll=new JScrollPane(cartList);cartScroll.setBorder(new MatteBorder(1,0,1,0,LINE));cartScroll.getViewport().setBackground(PANEL);cartScroll.setPreferredSize(new Dimension(0,260));summary.add(cartScroll,BorderLayout.CENTER);
        JPanel totals=new JPanel();totals.setOpaque(false);totals.setLayout(new BoxLayout(totals,BoxLayout.Y_AXIS));totals.add(summaryLine("Subtotal",subtotalValue));totals.add(Box.createVerticalStrut(7));totals.add(summaryLine("Descuento",label("Q0.00",13,TEXT)));totals.add(Box.createVerticalStrut(7));totals.add(summaryLine("Impuesto (12%)",taxValue));totals.add(Box.createVerticalStrut(10));
        JPanel totalBox=new RoundedPanel(10,GOLD);totalBox.setLayout(new BorderLayout());totalBox.setBorder(new EmptyBorder(10,12,10,12));JLabel tl=label("TOTAL",18,BG);tl.setFont(new Font("SansSerif",Font.BOLD,18));totalValue.setFont(new Font("SansSerif",Font.BOLD,25));totalBox.add(tl,BorderLayout.WEST);totalBox.add(totalValue,BorderLayout.EAST);totals.add(totalBox);summary.add(totals,BorderLayout.SOUTH);right.add(summary,BorderLayout.CENTER);

        JPanel pay=royalPanel(new BorderLayout(0,8),12);JLabel pt=label("▣   Método de pago",12,GOLD_2);pt.setFont(new Font("Serif",Font.BOLD,12));pay.add(pt,BorderLayout.NORTH);
        JPanel pbuttons=new JPanel(new GridLayout(1,3,8,0));pbuttons.setOpaque(false);paymentGroup.add(cashBtn);paymentGroup.add(cardBtn);paymentGroup.add(transferBtn);pbuttons.add(cashBtn);pbuttons.add(cardBtn);pbuttons.add(transferBtn);pay.add(pbuttons,BorderLayout.CENTER);
        JPanel fields=new JPanel(new GridLayout(1,2,10,0));fields.setOpaque(false);JPanel rec=new JPanel(new BorderLayout(6,0));rec.setOpaque(false);rec.add(label("Recibido",11,TEXT),BorderLayout.WEST);rec.add(receivedField,BorderLayout.CENTER);JPanel ch=new JPanel(new BorderLayout(6,0));ch.setOpaque(false);ch.add(label("Cambio",11,TEXT),BorderLayout.WEST);RoundedPanel cv=new RoundedPanel(8,new Color(11,34,29));cv.setBorder(new CompoundBorder(new LineBorder(new Color(41,126,87)),new EmptyBorder(8,10,8,10)));cv.setLayout(new BorderLayout());cv.add(changeValue,BorderLayout.CENTER);ch.add(cv,BorderLayout.CENTER);fields.add(rec);fields.add(ch);pay.add(fields,BorderLayout.SOUTH);
        receivedField.getDocument().addDocumentListener(new DocumentListener(){public void insertUpdate(DocumentEvent e){updateChange();}public void removeUpdate(DocumentEvent e){updateChange();}public void changedUpdate(DocumentEvent e){updateChange();}});
        JPanel lower=new JPanel(new BorderLayout(0,10));lower.setOpaque(false);lower.add(pay,BorderLayout.CENTER);JButton charge=roundedButton("▣      Cobrar     ›",GOLD,BG,18);charge.setPreferredSize(new Dimension(0,58));charge.addActionListener(e->chargeOrder());lower.add(charge,BorderLayout.SOUTH);right.add(lower,BorderLayout.SOUTH);
        return right;
    }

    private JPanel summaryLine(String left,JLabel right){JPanel p=new JPanel(new BorderLayout());p.setOpaque(false);p.add(label(left,12,MUTED),BorderLayout.WEST);p.add(right,BorderLayout.EAST);return p;}

    private void refreshProducts(){
        productsGrid.removeAll();String q=search.getText().trim().toLowerCase(Locale.ROOT);if(q.equals("buscar productos..."))q="";
        for(Product p:products){if(!p.category.equals(activeCategory))continue;if(!q.isEmpty()&&!p.name.toLowerCase(Locale.ROOT).contains(q))continue;productsGrid.add(productCard(p));}
        if(productsGrid.getComponentCount()==0){JPanel empty=new JPanel(new BorderLayout());empty.setBackground(BG);JLabel l=label("No hay productos para mostrar",15,MUTED);l.setHorizontalAlignment(SwingConstants.CENTER);empty.add(l,BorderLayout.CENTER);productsGrid.add(empty);}
        productsGrid.revalidate();productsGrid.repaint();productsScroll.getVerticalScrollBar().setValue(0);
    }

    private JComponent productCard(Product p){
        RoundedPanel card=new RoundedPanel(10,PANEL);card.setLayout(new BorderLayout(0,7));card.setBorder(new LineBorder(LINE));card.setPreferredSize(new Dimension(170,205));
        JLabel img=new JLabel();img.setHorizontalAlignment(SwingConstants.CENTER);img.setOpaque(true);img.setBackground(new Color(10,8,5));img.setIcon(loadIcon(p.image,170,112));card.add(img,BorderLayout.NORTH);
        JPanel body=new JPanel(new BorderLayout(4,3));body.setOpaque(false);body.setBorder(new EmptyBorder(0,9,8,9));JLabel name=label(p.name,12,TEXT);name.setFont(new Font("Serif",Font.BOLD,12));body.add(name,BorderLayout.NORTH);JLabel price=label(MONEY.format(p.price),18,GOLD_2);price.setFont(new Font("Serif",Font.BOLD,18));body.add(price,BorderLayout.WEST);JButton add=roundedButton("+",GOLD,BG,20);add.setPreferredSize(new Dimension(36,36));add.setMinimumSize(new Dimension(36,36));add.setMaximumSize(new Dimension(36,36));add.addActionListener(e->addToCart(p));JPanel addWrap=new JPanel(new GridBagLayout());addWrap.setOpaque(false);addWrap.add(add);body.add(addWrap,BorderLayout.EAST);card.add(body,BorderLayout.CENTER);
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));card.addMouseListener(new MouseAdapter(){public void mouseClicked(MouseEvent e){addToCart(p);}});return card;
    }

    private void refreshCart(){
        cartList.removeAll();
        if(cart.isEmpty()){JLabel empty=label("El pedido está vacío",13,MUTED);empty.setBorder(new EmptyBorder(25,10,25,10));empty.setAlignmentX(Component.CENTER_ALIGNMENT);cartList.add(empty);}
        for(Map.Entry<Product,Integer> en:cart.entrySet())cartList.add(cartRow(en.getKey(),en.getValue()));
        cartList.revalidate();cartList.repaint();double sub=subtotal();double tax=sub*0.12;subtotalValue.setText(MONEY.format(sub));taxValue.setText(MONEY.format(tax));totalValue.setText(MONEY.format(sub+tax));updateChange();
    }

    private JComponent cartRow(Product p,int qty){
        JPanel row=new JPanel(new BorderLayout(8,0));row.setBackground(new Color(58, 7, 10));row.setBorder(new CompoundBorder(new MatteBorder(0,0,1,0,LINE),new EmptyBorder(8,2,8,2)));row.setMaximumSize(new Dimension(Integer.MAX_VALUE,72));
        JLabel image=new JLabel(loadIcon(p.image,55,48));image.setPreferredSize(new Dimension(58,50));row.add(image,BorderLayout.WEST);
        JPanel text=new JPanel();text.setOpaque(false);text.setLayout(new BoxLayout(text,BoxLayout.Y_AXIS));JLabel n=label(p.name,12,TEXT);n.setFont(new Font("Serif",Font.BOLD,12));text.add(n);text.add(label(MONEY.format(p.price)+" c/u",11,MUTED));row.add(text,BorderLayout.CENTER);
        JPanel controls=new JPanel(new FlowLayout(FlowLayout.RIGHT,4,7));controls.setOpaque(false);JButton minus=smallButton("−");minus.addActionListener(e->changeQty(p,-1));JLabel q=label(String.valueOf(qty),12,TEXT);q.setPreferredSize(new Dimension(22,26));q.setHorizontalAlignment(SwingConstants.CENTER);JButton plus=smallButton("+");plus.addActionListener(e->changeQty(p,1));JLabel sum=label(MONEY.format(p.price*qty),12,TEXT);sum.setFont(new Font("SansSerif",Font.BOLD,12));JButton del=smallButton("✕");del.setForeground(new Color(255,72,100));del.addActionListener(e->{cart.remove(p);refreshCart();});controls.add(minus);controls.add(q);controls.add(plus);controls.add(Box.createHorizontalStrut(6));controls.add(sum);controls.add(del);row.add(controls,BorderLayout.EAST);return row;
    }

    private void addToCart(Product p){cart.put(p,cart.getOrDefault(p,0)+1);refreshCart();}
    private void changeQty(Product p,int delta){int n=cart.getOrDefault(p,0)+delta;if(n<=0)cart.remove(p);else cart.put(p,n);refreshCart();}
    private double subtotal(){double s=0;for(Map.Entry<Product,Integer> e:cart.entrySet())s+=e.getKey().price*e.getValue();return s;}
    private double total(){return subtotal()*1.12;}

    private void chargeOrder(){
        if(cart.isEmpty()){message("Agrega al menos un producto al pedido.","Pedido vacío");return;}
        double total=total();
        if(cashBtn.isSelected()){
            try{double received=Double.parseDouble(receivedField.getText().replace("Q","").trim());if(received<total){message("El monto recibido es menor que el total.","Monto insuficiente");return;}}catch(Exception ex){message("Ingresa un monto recibido válido.","Monto inválido");return;}
        }
        String id=String.format("#%06d",nextOrder++);String customer=String.valueOf(customerCombo.getSelectedItem());String state="Pendiente";String type=localBtn.isSelected()?"Local":"Para llevar";String time=LocalDateTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        orders.add(0,new OrderRecord(id,customer,state,total,time,type));
        message("Pedido "+id+" registrado correctamente.\nTotal: "+MONEY.format(total),"Cobro realizado");
        orderNo.setText("# Orden: "+String.format("%06d",nextOrder));cart.clear();receivedField.setText("0.00");refreshCart();refreshOrdersTable();
    }

    private void updateChange(){
        double r=0;try{r=Double.parseDouble(receivedField.getText().replace("Q","").trim());}catch(Exception ignored){}double c=Math.max(0,r-total());changeValue.setText(MONEY.format(c));
    }

    private void newOrder(){cart.clear();receivedField.setText("0.00");customerCombo.setSelectedIndex(0);localBtn.setSelected(true);cashBtn.setSelected(true);refreshCart();}

    private void showTicket(){
        StringBuilder sb=new StringBuilder("KINGNALD'S\n-----------------------------\n");
        if(cart.isEmpty()) sb.append("No hay productos en el pedido actual.\n");
        else for(Map.Entry<Product,Integer> e:cart.entrySet())sb.append(e.getValue()).append(" x ").append(e.getKey().name).append("  ").append(MONEY.format(e.getKey().price*e.getValue())).append("\n");
        sb.append("-----------------------------\nTOTAL: ").append(MONEY.format(total())).append("\nGracias por su compra.");
        JTextArea ta=new JTextArea(sb.toString(),16,34);ta.setEditable(false);ta.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13));JOptionPane.showMessageDialog(this,new JScrollPane(ta),"Vista previa del ticket",JOptionPane.INFORMATION_MESSAGE);
    }

    private void showNewClientDialog(){String name=JOptionPane.showInputDialog(this,"Nombre del cliente:","Nuevo cliente",JOptionPane.PLAIN_MESSAGE);if(name!=null&&!name.trim().isEmpty()){customerCombo.addItem(name.trim());customerCombo.setSelectedItem(name.trim());}}
    private void showOrderDetails(String id){for(OrderRecord o:orders)if(o.id.equals(id)){message("Pedido: "+o.id+"\nCliente: "+o.customer+"\nEstado: "+o.status+"\nTotal: "+MONEY.format(o.total)+"\nHora: "+o.time+"\nTipo: "+o.type,"Detalle del pedido");return;}}
    private void message(String text,String title){JOptionPane.showMessageDialog(this,text,title,JOptionPane.INFORMATION_MESSAGE);}

    private void refreshOrdersTable(){if(ordersModel==null)return;ordersModel.setRowCount(0);String f=statusFilter==null?"Todos los estados":String.valueOf(statusFilter.getSelectedItem());for(OrderRecord o:orders){if(!f.equals("Todos los estados")&&!o.status.equals(f))continue;ordersModel.addRow(new Object[]{o.id,o.customer,statusBadge(o.status),MONEY.format(o.total),o.time,o.type,"Ver"});}}
    private String statusBadge(String s){if(s.equals("Pendiente"))return "◷  Pendiente";if(s.equals("En preparación"))return "♨  En preparación";if(s.equals("Completado"))return "●  Completado";return "▣  Entregado";}

    private void updateCategoryStyles(String selected){for(Map.Entry<String,JButton> e:categoryButtons.entrySet()){boolean on=e.getKey().equals(selected);e.getValue().setBackground(on?GOLD:PANEL_2);e.getValue().setForeground(on?BG:GOLD_2);e.getValue().setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(8,11,8,11)));}}

    private void seedProducts(){
        // Productos e importes basados en el catálogo suministrado.
        addProduct("KingBurger Clásica",55,"Hamburguesas",38);addProduct("KingBurger Doble Corona",65,"Hamburguesas",39);addProduct("KingBurger BBQ Real",75,"Hamburguesas",40);addProduct("KingBurger Bacon Imperial",70,"Hamburguesas",41);addProduct("KingBurger Suprema",80,"Hamburguesas",42);addProduct("KingNald’s Burger",65,"Hamburguesas",1);
        addProduct("King Básico",65,"Combos",21);addProduct("King Clásico",75,"Combos",22);addProduct("King Real",85,"Combos",23);addProduct("King Premium",99,"Combos",24);addProduct("Desayuno del Rey con café",55,"Combos",29);addProduct("Burrito del Vigía con Café Helado",85,"Combos",34);
        addProduct("Cola King",15,"Bebidas",25);addProduct("Lemon King",25,"Bebidas",26);addProduct("Ice King",35,"Bebidas",27);addProduct("Cofee King",20,"Bebidas",28);
        addProduct("Papas del Reino",18,"Papas",21);addProduct("Papas Corona",22,"Papas",22);addProduct("Papas Premium",28,"Papas",24);addProduct("Papas Grandes",25,"Papas",23);
        addProduct("Pastel Dragón",55,"Postres",12);addProduct("Cheesecake Real",30,"Postres",13);addProduct("Churros del Castillo",45,"Postres",14);addProduct("Copa del Rey",30,"Postres",15);addProduct("Volcán de Chocolate",45,"Postres",16);addProduct("Tarta de Manzana",35,"Postres",20);
    }
    private void addProduct(String n,double p,String c,int page){products.add(new Product(n,p,c,String.format("/kingnalds/cajero/assets/product_%02d.jpg",page)));}

    private void seedOrders(){orders.add(new OrderRecord("#001248","Carlos Méndez","Pendiente",107.52,"10:24 a. m.","Local"));orders.add(new OrderRecord("#001247","Ana Rodríguez","En preparación",64,"10:18 a. m.","Para llevar"));orders.add(new OrderRecord("#001246","Luis Pérez","Completado",92,"10:15 a. m.","Drive Thru"));orders.add(new OrderRecord("#001245","Sofía Gómez","Entregado",118,"10:10 a. m.","A domicilio"));orders.add(new OrderRecord("#001244","Diego Herrera","En preparación",73,"10:05 a. m.","Para llevar"));orders.add(new OrderRecord("#001243","Valeria Torres","Completado",49,"09:58 a. m.","Local"));orders.add(new OrderRecord("#001242","Javier Morales","Pendiente",36,"09:52 a. m.","Drive Thru"));orders.add(new OrderRecord("#001241","Camila Rojas","Entregado",88,"09:47 a. m.","A domicilio"));}

    private void startClock(){javax.swing.Timer timer=new javax.swing.Timer(1000,e->{LocalDateTime n=LocalDateTime.now();dateLabel.setText(n.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM 'de' yyyy",new Locale("es","GT"))));timeLabel.setText(n.format(DateTimeFormatter.ofPattern("hh:mm:ss a",new Locale("es","GT"))).toLowerCase(Locale.ROOT));});timer.start();}

    private static JLabel label(String t,int s,Color c){JLabel l=new JLabel(t);l.setForeground(c);l.setFont(new Font("Serif",Font.PLAIN,s));return l;}
    private static JTextField darkField(String placeholder){JTextField f=new JTextField(placeholder);f.setBackground(PANEL_2);f.setForeground(MUTED);f.setCaretColor(GOLD);f.setFont(new Font("Serif",Font.PLAIN,12));f.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(8,12,8,12)));f.addFocusListener(new FocusAdapter(){public void focusGained(FocusEvent e){if(f.getText().equals(placeholder)){f.setText("");f.setForeground(TEXT);}}public void focusLost(FocusEvent e){if(f.getText().trim().isEmpty()){f.setText(placeholder);f.setForeground(MUTED);}}});return f;}
    private static JButton roundedButton(String text,Color bg,Color fg,int size){JButton b=new JButton(text);b.setBackground(bg);b.setForeground(fg);b.setFont(new Font("Serif",Font.BOLD,size));b.setFocusPainted(false);b.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(8,11,8,11)));b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));return b;}
    private static JButton smallButton(String t){JButton b=roundedButton(t,PANEL_2,TEXT,13);b.setPreferredSize(new Dimension(31,28));b.setBorder(new LineBorder(LINE));return b;}
    private static JToggleButton toggleButton(String t){JToggleButton b=new JToggleButton(t);b.setBackground(PANEL_2);b.setForeground(TEXT);b.setFocusPainted(false);b.setContentAreaFilled(true);b.setOpaque(true);b.setFont(new Font("Serif",Font.BOLD,12));b.setBorder(new LineBorder(LINE));b.addItemListener(e->{boolean s=b.isSelected();b.setBackground(s?GOLD:PANEL_2);b.setForeground(s?BG:TEXT);b.setBorder(new LineBorder(s?GOLD_2:LINE));});return b;}
    private static JToggleButton paymentButton(String t){JToggleButton b=toggleButton(t);b.addItemListener(e->{if(b.isSelected()){b.setBackground(GOLD);b.setForeground(BG);b.setBorder(new LineBorder(GOLD_2));}else{b.setBackground(PANEL_2);b.setForeground(TEXT);b.setBorder(new LineBorder(LINE));}});return b;}
    @SafeVarargs private static <T> JComboBox<T> darkCombo(T... items){JComboBox<T> c=new JComboBox<>(items);c.setBackground(PANEL_2);c.setForeground(TEXT);c.setFont(new Font("Serif",Font.PLAIN,12));c.setBorder(new LineBorder(LINE));return c;}
    private static JPanel cardPanel(LayoutManager lm,int pad){RoundedPanel p=new RoundedPanel(10,PANEL);p.setLayout(lm);p.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(pad,pad,pad,pad)));return p;}
    private static JPanel royalPanel(LayoutManager lm,int pad){RoundedPanel p=new RoundedPanel(10,new Color(58,7,10));p.setLayout(lm);p.setBorder(new CompoundBorder(new LineBorder(new Color(139,74,23)),new EmptyBorder(pad,pad,pad,pad)));return p;}
    private static ImageIcon loadIcon(String path,int w,int h){URL u=CashierApp.class.getResource(path);if(u==null)return new ImageIcon();Image im=new ImageIcon(u).getImage().getScaledInstance(w,h,Image.SCALE_SMOOTH);return new ImageIcon(im);}

    private static final class Product {final String name,category,image;final double price;Product(String n,double p,String c,String i){name=n;price=p;category=c;image=i;}public boolean equals(Object o){return o instanceof Product&&name.equals(((Product)o).name);}public int hashCode(){return name.hashCode();}}
    private static final class OrderRecord {final String id,customer,status,time,type;final double total;OrderRecord(String i,String c,String s,double t,String tm,String ty){id=i;customer=c;status=s;total=t;time=tm;type=ty;}}
    private static final class RoundedPanel extends JPanel {private final int radius;private final Color fill;RoundedPanel(int r,Color f){radius=r;fill=f;setOpaque(false);}protected void paintComponent(Graphics g){Graphics2D g2=(Graphics2D)g.create();g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g2.setColor(fill);g2.fillRoundRect(0,0,getWidth(),getHeight(),radius,radius);g2.dispose();super.paintComponent(g);}}
}
