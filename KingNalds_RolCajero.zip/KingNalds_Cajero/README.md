# KingNald's Cajero

Proyecto Java Swing para NetBeans inspirado en las interfaces de referencia del rol Cajero.

## Funciones incluidas
- Navegación por categorías.
- Buscador de productos.
- Tarjetas de productos con imágenes del catálogo suministrado.
- Carrito interactivo con aumentar, reducir y eliminar.
- Cálculo de subtotal, IVA 12% y total.
- Métodos de pago y cálculo de cambio.
- Selección de cliente y tipo de pedido.
- Vista de lista de pedidos con filtro por estado.
- Vista previa de ticket.
- Alta temporal de cliente.
- Cobro y creación de pedidos en memoria.

No usa base de datos todavía; esa capa puede conectarse posteriormente.
